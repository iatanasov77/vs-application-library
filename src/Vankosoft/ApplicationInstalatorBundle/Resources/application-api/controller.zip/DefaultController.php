<?php namespace App\Controller\__application_name__;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Twig\Environment;
use Vankosoft\ApplicationBundle\Component\Context\ApplicationContextInterface;

class DefaultController extends AbstractController
{
    /** @var ApplicationContextInterface */
    private $applicationContext;
    
    /** @var Environment */
    private $templatingEngine;
    
    public function __construct(
        ApplicationContextInterface $applicationContext,
        Environment $templatingEngine
    ) {
        $this->applicationContext               = $applicationContext;
        $this->templatingEngine                 = $templatingEngine;
    }
    
    public function index( Request $request ): Response
    {
        return new Response( $this->templatingEngine->render( $this->getTemplate(), [
            'oApplication' => $this->applicationContext->getApplication(),
        ]));
    }
    
    protected function getTemplate(): string
    {
        $template   = '@VSApi/Pages/home.html.twig';
        
        $appSettings    = $this->applicationContext->getApplication()->getSettings();
        if ( ! $appSettings->isEmpty() && $appSettings[0]->getTheme() ) {
            $template   = 'Pages/api-home.html.twig';
        }
        
        return $template;
    }
}
