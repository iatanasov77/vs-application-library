<?php namespace App\Controller\__application_name__;

use Symfony\Component\HttpFoundation\Request;
use Vankosoft\CatalogBundle\Controller\ProductController as BaseProductController;

class ProductController extends BaseProductController
{
    use GlobalFormsTrait;
    
    protected function customData( Request $request, $entity = null ): array
    {
        $customData = parent::customData( $request, $entity );
        
        $customData['shoppingCart'] = $this->getShoppingCart( $request );
        $customData['searchProductForm'] = $this->searchProductForm(),
        
        return $customData;
    }
}